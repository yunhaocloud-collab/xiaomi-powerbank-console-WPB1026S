export type RegionResult =
  { status: 'mainland' | 'outside'; country: string } | { status: 'unavailable'; country: null }

// ISO 3166-1 alpha-2 codes. Unknown/reserved values must not grant access.
const COUNTRY_CODES = new Set(
  (
    'AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ ' +
    'CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR ' +
    'GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP ' +
    'KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ ' +
    'NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW ' +
    'SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ ' +
    'UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'
  ).split(' '),
)

/** IP location only; never send device data, persist the IP, or infer from language/timezone. */
export async function detectRegion(): Promise<RegionResult> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 8000)
  try {
    const response = await fetch('https://api.country.is/', {
      signal: controller.signal,
      credentials: 'omit',
      referrerPolicy: 'no-referrer',
      cache: 'no-store',
    })
    if (!response.ok) return { status: 'unavailable', country: null }
    const data: unknown = await response.json()
    const country = data && typeof data === 'object' && 'country' in data ? data.country : null
    if (typeof country !== 'string' || !COUNTRY_CODES.has(country)) {
      return { status: 'unavailable', country: null }
    }
    return { status: country === 'CN' ? 'mainland' : 'outside', country }
  } catch {
    return { status: 'unavailable', country: null }
  } finally {
    clearTimeout(timer)
  }
}
