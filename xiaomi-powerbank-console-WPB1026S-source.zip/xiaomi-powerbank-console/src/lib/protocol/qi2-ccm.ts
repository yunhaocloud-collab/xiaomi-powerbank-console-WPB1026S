// Port of qi2_ccm.py from the user-supplied WPB1026S-fixed tool.
// Public protocol constant, not a user credential. No device data leaves the browser.
const ROOT_KEY = new TextEncoder().encode('MiXiaomiQi22Key!')

/** Fixed five-byte Qi2 settings payload, AES-128-CCM, tag=4, nonce=13, no AAD. */
export async function encryptedQi2Payload(
  serial: string,
  timestamp: number,
  health: number,
  cycles: number,
  enabled: boolean,
): Promise<Uint8Array<ArrayBuffer>> {
  if (!/^[\x20-\x7e]+$/.test(serial)) throw new Error('Invalid device serial')
  if (!Number.isInteger(timestamp) || timestamp < 0 || timestamp > 0xffffffff) {
    throw new Error('Invalid Hello timestamp')
  }
  if (
    !Number.isInteger(health) ||
    health < 0 ||
    health > 100 ||
    !Number.isInteger(cycles) ||
    cycles < 0 ||
    cycles > 0xffff
  )
    throw new Error('Invalid battery health/cycle values')
  if (typeof enabled !== 'boolean') throw new Error('Invalid Qi2 setting')
  if (!globalThis.crypto?.subtle) throw new Error('Web Crypto requires HTTPS or localhost')

  const subtle = globalThis.crypto.subtle
  const material = new Uint8Array(12)
  const suffix = new TextEncoder().encode(serial.slice(-8))
  material.set(suffix, 8 - suffix.length) // Left pad with zero bytes, not ASCII zeroes.
  new DataView(material.buffer).setUint32(8, timestamp, false)
  const root = await subtle.importKey('raw', ROOT_KEY, { name: 'HMAC', hash: 'SHA-256' }, false, [
    'sign',
  ])
  const digest = await subtle.sign('HMAC', root, material)
  const key = await subtle.importKey('raw', digest.slice(0, 16), 'AES-CBC', false, ['encrypt'])

  const nonce = new Uint8Array(13)
  nonce[0] = 0x48
  new DataView(nonce.buffer).setUint32(1, timestamp, false)
  nonce[9] = 0xe6
  const plain = new Uint8Array(5)
  const view = new DataView(plain.buffer)
  view.setUint16(0, health, false)
  view.setUint16(2, cycles, false)
  plain[4] = enabled ? 1 : 0

  // Web Crypto has no CCM. AES-CBC with a zero IV gives AES(block) in the
  // first output block; discard the extra PKCS#7 padding block. CCM below
  // is deliberately restricted to this protocol's five-byte message.
  const aesBlock = async (block: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> =>
    new Uint8Array(
      await subtle.encrypt({ name: 'AES-CBC', iv: new Uint8Array(16) }, key, block),
    ).slice(0, 16)
  const b0 = new Uint8Array(16)
  b0[0] = 0x09 // No AAD, four-byte tag, two-byte message length.
  b0.set(nonce, 1)
  b0[15] = plain.length
  const macInput = await aesBlock(b0)
  for (let i = 0; i < plain.length; i += 1) macInput[i] = macInput[i]! ^ plain[i]!
  const mac = await aesBlock(macInput)
  const counter = new Uint8Array(16)
  counter[0] = 1
  counter.set(nonce, 1)
  const s0 = await aesBlock(counter)
  counter[15] = 1
  const s1 = await aesBlock(counter)
  const result = new Uint8Array(9)
  for (let i = 0; i < 5; i += 1) result[i] = plain[i]! ^ s1[i]!
  for (let i = 0; i < 4; i += 1) result[5 + i] = mac[i]! ^ s0[i]!
  return result
}
