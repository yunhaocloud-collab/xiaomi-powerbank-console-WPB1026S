import { createPinia, setActivePinia } from 'pinia'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { DeviceClient } from '@/lib/hid/device-client'
import { MockTransport } from '@/lib/hid/mock-transport'
import { useDeviceStore } from '@/stores/device'
import type { Qi2Status } from '@/types/device'
import { detectRegion } from '@/lib/region'

vi.mock('@/lib/region', () => ({ detectRegion: vi.fn() }))

const feedback = vi.hoisted(() => ({ success: vi.fn(), error: vi.fn(), show: vi.fn() }))
vi.mock('@/composables/useToast', () => ({ useToast: () => feedback }))
vi.mock('@/lib/hid/webhid-transport', () => ({
  WebHidTransport: {
    isSupported: () => true,
    request: async () => new MockTransport(16, 'SYNTHETIC123456789'),
  },
}))

describe('WPB1026S dashboard state', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
    vi.mocked(detectRegion).mockReset().mockResolvedValue({ status: 'outside', country: 'US' })
  })
  afterEach(() => vi.restoreAllMocks())

  it('exposes the switch, requires confirmation, and displays both read-back states', async () => {
    const store = useDeviceStore()
    await store.connect()
    try {
      expect(store.modelId).toBe(16)
      expect(store.supportsQi2Toggle).toBe(true)
      expect(store.qi2Status?.enabled).toBe(false)
      store.requestQi2Toggle(true)
      expect(store.qi2ConfirmOpen).toBe(true)
      expect(store.qi2Status?.enabled).toBe(false)
      store.cancelQi2Toggle()
      expect(store.qi2Status?.enabled).toBe(false)
      store.requestQi2Toggle(true)
      await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
      store.qi2Consent = true
      await store.confirmQi2Toggle()
      expect(store.qi2Status?.enabled).toBe(true)
      store.requestQi2Toggle(false)
      await store.confirmQi2Toggle()
      expect(store.qi2Status?.enabled).toBe(false)
      expect(feedback.error).not.toHaveBeenCalled()
    } finally {
      await store.exitDemo()
    }
  })

  it('shows unknown rather than inventing a successful state when verification fails', async () => {
    const store = useDeviceStore()
    await store.connect()
    try {
      feedback.success.mockClear()
      vi.spyOn(DeviceClient.prototype, 'setQi2').mockRejectedValueOnce(
        new Error('Read-back timed out'),
      )
      store.requestQi2Toggle(true)
      await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
      store.qi2Consent = true
      await store.confirmQi2Toggle()
      expect(store.qi2Status).toBeNull()
      expect(store.qi2Toggling).toBe(false)
      expect(feedback.success).not.toHaveBeenCalled()
      expect(feedback.error).toHaveBeenCalledOnce()
      await store.reloadQi2Status()
      expect(store.qi2Status?.enabled).toBe(false)
    } finally {
      await store.exitDemo()
    }
  })

  it('does not apply an old session result after disconnect and reconnect', async () => {
    const store = useDeviceStore()
    await store.connect()
    let finish!: (status: Qi2Status) => void
    vi.spyOn(DeviceClient.prototype, 'setQi2').mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = resolve
        }),
    )
    store.requestQi2Toggle(true)
    await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
    store.qi2Consent = true
    const pending = store.confirmQi2Toggle()
    await vi.waitFor(() => expect(finish).toBeTypeOf('function'))
    await store.exitDemo()
    await store.connect()
    feedback.success.mockClear()
    finish({ statusCode: 0, success: true, enabled: true, rawPayload: new Uint8Array([0, 1]) })
    await pending
    expect(store.qi2Status?.enabled).toBe(false)
    expect(feedback.success).not.toHaveBeenCalled()
    await store.exitDemo()
  })

  it.each(['mainland', 'unavailable'] as const)(
    'blocks enabling when the region is %s',
    async (status) => {
      vi.mocked(detectRegion).mockResolvedValue(
        status === 'mainland' ? { status, country: 'CN' } : { status, country: null },
      )
      const store = useDeviceStore()
      await store.connect()
      const write = vi.spyOn(DeviceClient.prototype, 'setQi2')
      try {
        store.requestQi2Toggle(true)
        await vi.waitFor(() => expect(store.qi2Region.status).toBe(status))
        store.qi2Consent = true
        await store.confirmQi2Toggle()
        expect(write).not.toHaveBeenCalled()
        expect(store.qi2Status?.enabled).toBe(false)
      } finally {
        await store.exitDemo()
      }
    },
  )

  it('requires consent and an open dialog even after a successful region check', async () => {
    const store = useDeviceStore()
    await store.connect()
    const write = vi.spyOn(DeviceClient.prototype, 'setQi2')
    try {
      store.requestQi2Toggle(true)
      await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
      await store.confirmQi2Toggle()
      expect(write).not.toHaveBeenCalled()
      store.cancelQi2Toggle()
      store.qi2Consent = true
      await store.confirmQi2Toggle()
      expect(write).not.toHaveBeenCalled()
    } finally {
      await store.exitDemo()
    }
  })

  it('does not enable while detecting and ignores a response after cancellation', async () => {
    let finish!: (value: { status: 'outside'; country: string }) => void
    vi.mocked(detectRegion).mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = resolve
        }),
    )
    const store = useDeviceStore()
    await store.connect()
    const write = vi.spyOn(DeviceClient.prototype, 'setQi2')
    try {
      store.requestQi2Toggle(true)
      expect(store.qi2Region.status).toBe('checking')
      store.qi2Consent = true
      await store.confirmQi2Toggle()
      expect(write).not.toHaveBeenCalled()
      store.cancelQi2Toggle()
      finish({ status: 'outside', country: 'US' })
      await Promise.resolve()
      expect(store.qi2Region.status).toBe('idle')
      expect(store.qi2Consent).toBe(false)
      expect(store.qi2ConfirmOpen).toBe(false)
    } finally {
      await store.exitDemo()
    }
  })

  it('rechecks on consent and blocks if the network changes to mainland China', async () => {
    const store = useDeviceStore()
    await store.connect()
    const write = vi.spyOn(DeviceClient.prototype, 'setQi2')
    try {
      store.requestQi2Toggle(true)
      await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
      store.qi2Consent = true
      vi.mocked(detectRegion).mockResolvedValueOnce({ status: 'mainland', country: 'CN' })
      await store.confirmQi2Toggle()
      expect(store.qi2Region.status).toBe('mainland')
      expect(store.qi2Consent).toBe(false)
      expect(write).not.toHaveBeenCalled()
    } finally {
      await store.exitDemo()
    }
  })

  it('allows disabling without a region request or enabling consent', async () => {
    const store = useDeviceStore()
    await store.connect()
    try {
      store.requestQi2Toggle(true)
      await vi.waitFor(() => expect(store.qi2Region.status).toBe('outside'))
      store.qi2Consent = true
      await store.confirmQi2Toggle()
      expect(store.qi2Status?.enabled).toBe(true)
      vi.mocked(detectRegion).mockClear().mockResolvedValue({ status: 'mainland', country: 'CN' })
      store.requestQi2Toggle(false)
      await store.confirmQi2Toggle()
      expect(store.qi2Status?.enabled).toBe(false)
      expect(detectRegion).not.toHaveBeenCalled()
    } finally {
      await store.exitDemo()
    }
  })
})
