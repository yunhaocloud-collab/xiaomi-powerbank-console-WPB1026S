import { createCipheriv, createHmac } from 'node:crypto'
import { describe, expect, it } from 'vitest'
import { encryptedQi2Payload } from '@/lib/protocol/qi2-ccm'

// Independent OpenSSL CCM implementation, not the browser implementation's
// CBC-MAC/CTR steps. All identifiers below are synthetic.
function reference(
  serial: string,
  timestamp: number,
  health: number,
  cycles: number,
  enabled: boolean,
) {
  const material = Buffer.alloc(12)
  const suffix = Buffer.from(serial.slice(-8), 'ascii')
  suffix.copy(material, 8 - suffix.length)
  material.writeUInt32BE(timestamp, 8)
  const key = createHmac('sha256', 'MiXiaomiQi22Key!').update(material).digest().subarray(0, 16)
  const nonce = Buffer.alloc(13)
  nonce[0] = 0x48
  nonce.writeUInt32BE(timestamp, 1)
  nonce[9] = 0xe6
  const plain = Buffer.alloc(5)
  plain.writeUInt16BE(health, 0)
  plain.writeUInt16BE(cycles, 2)
  plain[4] = enabled ? 1 : 0
  const cipher = createCipheriv('aes-128-ccm', key, nonce, { authTagLength: 4 })
  cipher.setAAD(Buffer.alloc(0), { plaintextLength: plain.length })
  return Buffer.concat([cipher.update(plain), cipher.final(), cipher.getAuthTag()])
}

describe('WPB1026S encrypted settings', () => {
  for (const serial of ['SYNTHETIC000123456789', 'ABC', '12345678']) {
    for (const timestamp of [0, 0x11223344, 0xffffffff]) {
      for (const enabled of [false, true]) {
        it(`matches OpenSSL CCM for ${serial}, ${timestamp}, ${enabled}`, async () => {
          const payload = await encryptedQi2Payload(serial, timestamp, 95, 1234, enabled)
          expect(Buffer.from(payload)).toEqual(reference(serial, timestamp, 95, 1234, enabled))
        })
      }
    }
  }

  it('matches the supplied Python enable vector', async () => {
    expect(
      Buffer.from(
        await encryptedQi2Payload('SYNTHETIC000123456789', 0x11223344, 100, 1, true),
      ).toString('hex'),
    ).toBe('05f8b80d1e7f92ab31')
  })

  it('preserves boundary health and cycle values', async () => {
    expect(Buffer.from(await encryptedQi2Payload('BOUNDARY12345678', 1, 0, 65535, false))).toEqual(
      reference('BOUNDARY12345678', 1, 0, 65535, false),
    )
  })

  it.each([
    ['', 1, 100, 0],
    ['非ASCII', 1, 100, 0],
    ['A\n', 1, 100, 0],
    ['ABC', -1, 100, 0],
    ['ABC', 0x100000000, 100, 0],
    ['ABC', 1.5, 100, 0],
    ['ABC', 1, 101, 0],
    ['ABC', 1, -1, 0],
    ['ABC', 1, 99.5, 0],
    ['ABC', 1, 100, 65536],
    ['ABC', 1, 100, -1],
    ['ABC', 1, 100, NaN],
  ] as const)(
    'rejects invalid inputs (%s, %s, %s, %s)',
    async (serial, timestamp, health, cycles) => {
      await expect(encryptedQi2Payload(serial, timestamp, health, cycles, true)).rejects.toThrow()
    },
  )
})
