import { afterEach, describe, expect, it, vi } from 'vitest'
import { detectRegion } from '@/lib/region'

afterEach(() => {
  vi.unstubAllGlobals()
  vi.useRealTimers()
})

describe('IP region detection', () => {
  it.each(['CN', 'US', 'HK', 'MO', 'TW', 'DE'])('classifies %s', async (country) => {
    const fetcher = vi
      .fn()
      .mockResolvedValue(new Response(JSON.stringify({ country, ip: '192.0.2.1' })))
    vi.stubGlobal('fetch', fetcher)
    expect(await detectRegion()).toEqual({
      status: country === 'CN' ? 'mainland' : 'outside',
      country,
    })
    expect(fetcher).toHaveBeenCalledWith(
      'https://api.country.is/',
      expect.objectContaining({
        credentials: 'omit',
        referrerPolicy: 'no-referrer',
        cache: 'no-store',
      }),
    )
    expect(fetcher.mock.calls[0]?.[1]).not.toHaveProperty('body')
  })

  it.each([
    {},
    null,
    { country: '' },
    { country: 'ZZ' },
    { country: 'XX' },
    { country: 'cn' },
    { country: 'China' },
    { country: 1 },
  ])('fails closed for invalid data %j', async (data) => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify(data))))
    expect(await detectRegion()).toEqual({ status: 'unavailable', country: null })
  })

  it.each([429, 500, 403])('fails closed on HTTP %s', async (status) => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('{}', { status })))
    expect((await detectRegion()).status).toBe('unavailable')
  })

  it('fails closed on a network error or invalid JSON', async () => {
    vi.stubGlobal(
      'fetch',
      vi
        .fn()
        .mockRejectedValueOnce(new TypeError('offline'))
        .mockResolvedValueOnce(new Response('not json')),
    )
    expect((await detectRegion()).status).toBe('unavailable')
    expect((await detectRegion()).status).toBe('unavailable')
  })

  it('aborts after eight seconds and fails closed', async () => {
    vi.useFakeTimers()
    vi.stubGlobal(
      'fetch',
      vi.fn(
        (_url: string, options: RequestInit) =>
          new Promise((_resolve, reject) => {
            options.signal?.addEventListener('abort', () => reject(new Error('aborted')))
          }),
      ),
    )
    const result = detectRegion()
    await vi.advanceTimersByTimeAsync(8000)
    expect((await result).status).toBe('unavailable')
    expect(vi.getTimerCount()).toBe(0)
  })
})
