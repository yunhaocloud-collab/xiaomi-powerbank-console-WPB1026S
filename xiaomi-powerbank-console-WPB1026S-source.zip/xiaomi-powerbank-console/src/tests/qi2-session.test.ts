import { describe, expect, it } from 'vitest'
import { DeviceClient } from '@/lib/hid/device-client'
import { MockTransport } from '@/lib/hid/mock-transport'
import { buildCommandFrame, parseFrame } from '@/lib/protocol/frames'
import { CMD, RESPONSE_CMD } from '@/lib/protocol/constants'

class ObservedTransport extends MockTransport {
  readonly sent: Uint8Array[] = []
  rewrite: (frame: Uint8Array) => Uint8Array | null = (frame) => frame

  override async send(frame: Uint8Array): Promise<void> {
    this.sent.push(frame.slice())
    await super.send(frame)
  }

  override onInputReport(listener: (data: Uint8Array) => void): () => void {
    return super.onInputReport((frame) => {
      const rewritten = this.rewrite(frame)
      if (rewritten) listener(rewritten)
    })
  }

  get commands() {
    return this.sent.map((frame) => frame[1])
  }
}

describe('Qi2 transactions', () => {
  it.each([9, 19, 16])('enables and disables model %s with read-back', async (modelId) => {
    const transport = new ObservedTransport(modelId, 'SYNTHETIC123456789')
    const client = new DeviceClient(transport)
    await client.open()
    try {
      expect(await client.setQi2(true)).toMatchObject({ success: true, enabled: true })
      expect(await client.setQi2(false)).toMatchObject({ success: true, enabled: false })
      const write = modelId === 16 ? CMD.SET_QI2_ENCRYPTED : CMD.ENABLE_QI2
      expect(transport.commands.filter((cmd) => cmd === write)).toHaveLength(2)
      expect(transport.commands).not.toContain(
        modelId === 16 ? CMD.ENABLE_QI2 : CMD.SET_QI2_ENCRYPTED,
      )
      const info = await client.getBatteryInfo()
      expect(info.health).toBe(97)
      expect(info.cycleCount).toBe(37)
    } finally {
      await client.close()
    }
  })

  it('serializes heartbeats and refreshes around the complete encrypted transaction', async () => {
    const transport = new ObservedTransport(16)
    const client = new DeviceClient(transport)
    await client.open()
    try {
      const [, result] = await Promise.all([
        client.sendHeartbeat(),
        client.setQi2(true),
        client.sendHeartbeat(),
        client.getBatteryInfo(),
      ])
      expect(result.enabled).toBe(true)
      expect(transport.commands).toEqual([0, 0, 7, 1, 0xe6, 7, 0, 1])
    } finally {
      await client.close()
    }
  })

  it('does not write if the target is already set', async () => {
    const transport = new ObservedTransport(16)
    const client = new DeviceClient(transport)
    await client.open()
    try {
      expect((await client.setQi2(false)).enabled).toBe(false)
      expect(transport.commands).toEqual([0, 7])
    } finally {
      await client.close()
    }
  })

  it.each([10, 12, 65535])('rejects unsupported model %s before any write', async (modelId) => {
    const transport = new ObservedTransport(modelId)
    const client = new DeviceClient(transport)
    await client.open()
    try {
      await expect(client.setQi2(true)).rejects.toThrow('not supported')
      expect(transport.commands).toEqual([0])
    } finally {
      await client.close()
    }
  })

  it.each(['rejected', 'mismatch', 'query-error', 'query-timeout', 'bad-crc'])(
    'never reports success for %s',
    async (failure) => {
      const transport = new ObservedTransport(16)
      let queries = 0
      transport.rewrite = (frame) => {
        const parsed = parseFrame(frame)
        if (parsed.command === RESPONSE_CMD.SET_QI2_ENCRYPTED) {
          if (failure === 'rejected') return buildCommandFrame(parsed.command, new Uint8Array([1]))
          if (failure === 'bad-crc') {
            frame[4] = frame[4]! ^ 1
            return frame
          }
        }
        if (parsed.command === RESPONSE_CMD.QI2_STATUS && ++queries === 2) {
          if (failure === 'query-timeout') return null
          if (failure === 'mismatch')
            return buildCommandFrame(parsed.command, new Uint8Array([0, 0]))
          if (failure === 'query-error')
            return buildCommandFrame(parsed.command, new Uint8Array([1, 1]))
        }
        return frame
      }
      const client = new DeviceClient(transport)
      await client.open()
      try {
        await expect(client.setQi2(true)).rejects.toThrow()
      } finally {
        await client.close()
      }
    },
    7000,
  )

  it.each(['status', 'health', 'short', 'fault'])(
    'does not encrypt invalid battery data: %s',
    async (failure) => {
      const transport = new ObservedTransport(16)
      transport.rewrite = (frame) => {
        const parsed = parseFrame(frame)
        if (parsed.command !== RESPONSE_CMD.BATTERY_INFO) return frame
        const payload = parsed.payload.slice()
        if (failure === 'status') payload[0] = 1
        if (failure === 'health') payload[4] = 101
        if (failure === 'fault') payload[6] = 0x41
        return buildCommandFrame(
          parsed.command,
          failure === 'short' ? payload.slice(0, 4) : payload,
        )
      }
      const client = new DeviceClient(transport)
      await client.open()
      try {
        await expect(client.setQi2(true)).rejects.toThrow()
        expect(transport.commands).not.toContain(CMD.SET_QI2_ENCRYPTED)
      } finally {
        await client.close()
      }
    },
  )

  it('cancels queued writes on disconnect', async () => {
    const transport = new ObservedTransport(16)
    const client = new DeviceClient(transport)
    await client.open()
    const setting = expect(client.setQi2(true)).rejects.toThrow()
    await client.close()
    await setting
    expect(transport.commands).not.toContain(CMD.SET_QI2_ENCRYPTED)
  })
})
