<script setup lang="ts">
import { computed } from 'vue'
import AppModal from './AppModal.vue'
import { useDeviceStore } from '@/stores/device'
import { useI18n } from '@/composables/useI18n'

const store = useDeviceStore()
const { t, lang } = useI18n()
const regionName = computed(() => {
  const country = store.qi2Region.country
  return country
    ? (new Intl.DisplayNames([lang.value], { type: 'region' }).of(country) ?? country)
    : ''
})
</script>

<template>
  <AppModal
    :open="store.qi2ConfirmOpen && store.qi2PendingEnable"
    :title="t('qi2Gate.title')"
    :ok-text="t('qi2Gate.agree')"
    :cancel-text="t('qi2Gate.cancel')"
    :show-confirm="store.qi2Region.status === 'outside'"
    :confirm-disabled="
      !store.qi2Consent || store.qi2Toggling || store.refreshing || store.qi2Loading
    "
    tone="danger"
    icon="shield"
    wide
    @close="store.cancelQi2Toggle()"
    @confirm="store.confirmQi2Toggle()"
  >
    <div
      class="region-status"
      :class="`region-status--${store.qi2Region.status}`"
      role="status"
      aria-live="polite"
    >
      <template v-if="store.qi2RegionChecking">
        <span class="spinner" aria-hidden="true"></span> {{ t('qi2Gate.checking') }}
      </template>
      <template v-else-if="store.qi2Region.status === 'mainland'">
        <strong>{{ t('qi2Gate.blocked') }}</strong>
        <p>{{ t('qi2Gate.blockedBody') }}</p>
      </template>
      <template v-else-if="store.qi2Region.status === 'outside'">
        <strong>{{ t('qi2Gate.outside', { region: regionName }) }}</strong>
        <p>{{ t('qi2Gate.outsideBody') }}</p>
      </template>
      <template v-else>
        <strong>{{ t('qi2Gate.unavailable') }}</strong>
        <p>{{ t('qi2Gate.unavailableBody') }}</p>
      </template>
    </div>

    <div class="qi2-warning">
      <h3>{{ t('qi2Gate.warningTitle') }}</h3>
      <ul>
        <li>{{ t('qi2Gate.regionRule') }}</li>
        <li>{{ t('qi2Gate.localRules') }}</li>
        <li>{{ t('qi2Gate.deviceRisk') }}</li>
        <li>{{ t('qi2Gate.verification') }}</li>
      </ul>
    </div>
    <p class="region-privacy">{{ t('qi2Gate.privacy') }}</p>

    <label v-if="store.qi2Region.status === 'outside'" class="qi2-consent">
      <input v-model="store.qi2Consent" type="checkbox" />
      <span>{{ t('qi2Gate.consent') }}</span>
    </label>
    <button
      v-if="store.qi2Region.status === 'mainland' || store.qi2Region.status === 'unavailable'"
      type="button"
      class="btn btn--ghost region-retry"
      @click="store.checkQi2Region()"
    >
      {{ t('qi2Gate.retry') }}
    </button>
  </AppModal>
</template>

<style scoped>
.region-status {
  margin-top: 20px;
  padding: 14px 16px;
  border-radius: 12px;
  background: var(--color-bg);
  font-size: 0.9rem;
  line-height: 1.65;
}
.region-status p {
  margin-top: 4px;
}
.region-status--mainland,
.region-status--unavailable {
  color: var(--color-danger);
  background: var(--color-danger-soft);
}
.region-status--outside {
  color: var(--color-success);
  background: var(--color-success-soft);
}
.region-status .spinner {
  display: inline-block;
  width: 14px;
  height: 14px;
  vertical-align: middle;
  margin-right: 6px;
}
.qi2-warning {
  margin-top: 18px;
  border: 1px solid var(--color-danger);
  border-radius: 12px;
  padding: 16px;
}
.qi2-warning h3 {
  color: var(--color-danger);
  font-size: 1rem;
}
.qi2-warning ul {
  margin-top: 10px;
  padding-left: 20px;
  font-size: 0.88rem;
  line-height: 1.75;
}
.qi2-warning li + li {
  margin-top: 8px;
}
.region-privacy {
  margin-top: 14px;
  color: var(--color-muted);
  font-size: 0.78rem;
  line-height: 1.65;
}
.qi2-consent {
  display: flex;
  gap: 10px;
  align-items: flex-start;
  margin-top: 18px;
  font-size: 0.9rem;
  line-height: 1.7;
  cursor: pointer;
}
.qi2-consent input {
  width: 18px;
  height: 18px;
  flex: 0 0 18px;
  margin-top: 3px;
  accent-color: var(--color-danger);
}
.region-retry {
  margin-top: 12px;
}
</style>
