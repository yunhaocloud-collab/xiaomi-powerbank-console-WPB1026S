# Xiaomi Power Bank Console · WPB1026S Qi2.2

一个用 **Vue 3 + TypeScript + WebHID** 重写的「小米移动电源详情」前端。项目从公开网页 [`powerbank.mieco.net`](https://powerbank.mieco.net/) 的 WebHID 行为逆向而来，可部署到 **Cloudflare Pages**。本版本已移除首页演示入口。

在线站点：[mipluswpb1026s.pages.dev](https://mipluswpb1026s.pages.dev/)

本项目基于 [LOSRET/xiaomi-powerbank-console](https://github.com/LOSRET/xiaomi-powerbank-console) 扩展，保留原项目署名和 MIT 许可证。

## 本版本新增：WPB1026S Qi2.2 支持

**已加入小米金沙江充电宝新国标 10000mAh 45W（WPB1026S）的 Qi2.2 开启与关闭功能支持。**

- 根据当前设备序列号和本次握手生成加密设置命令，不跨设备复用固定命令。
- 开启和关闭均需确认；只有设备返回成功且回读状态一致，才显示操作成功。
- 开启前检测公网 IP 地区：中国大陆、检测失败或超时均禁止开启；非大陆地区需知情同意，并再次检测。关闭不受地区检测限制。
- 移除首页“查看演示数据”按钮和第三方访问统计脚本。

验证范围：原 Python 修复程序由用户反馈已成功开启 WPB1026S；浏览器移植版和关闭操作仍需实机验证。自动测试 112 项通过，不能代替不同固件的实机验收。“已开启”表示设备设置位已开启，不代表手机正在使用 Qi2.2 或达到特定充电功率。详见 [使用与验证说明](docs/WPB1026S_QI2.md)。

> 非官方工具，与小米公司无隶属关系。所有设备数据只在浏览器内解析，不会上传到服务器。

![桌面端演示模式](docs/images/desktop-demo.png)

<sub>以上为上游界面截图，仅供布局参考；本版本首页已移除演示入口。移动端效果见 [mobile-demo.png](docs/images/mobile-demo.png)，支持型号页见 [models.png](docs/images/models.png)。</sub>

## 功能

- 通过 WebHID 连接小米移动电源（VID `0x2717` / `0x1A86`，产品名 `XiaomiPowerBank`）
- 读取并展示：
  - 产品名称、型号、SN
  - 当前电量、充放电状态
  - 电池健康度、循环次数、电池温度、串总电压、电流
  - 电芯数量、单节电芯电压、生产日期、电芯编码
  - 电池温度阈值与电池型号（支持的型号）
  - 本地异常记录（按时间倒序、分页）
- Qi2.2 无线充电开关（小米金沙江充电宝 超薄磁吸 10000 45W：`WPB1025S` 和新国标 `WPB1026S`；开启/关闭均需二次确认与设备回读；[WPB1026S 使用及验证说明](docs/WPB1026S_QI2.md)）
- 15 秒 Hello 心跳保活，连接期间保持屏幕唤醒
- 内置模拟传输层用于自动测试，首页不提供演示数据按钮
- 中 / 英双语，自动检测系统语言，可手动切换并记忆
- HID 通信记录查看器，可核对原始帧、CRC 和收发方向
- 支持型号表与异常处理指引
- 纯静态构建；设备数据不上传。开启 Qi2.2 前使用 country.is 检测公网 IP 地区，无第三方访问量统计脚本

## 浏览器要求

| 浏览器                       | 支持情况         |
| ---------------------------- | ---------------- |
| 桌面版 Chrome / Edge / Opera | ✅ 支持          |
| 桌面版 Chromium 内核浏览器   | ✅ 通常支持      |
| Firefox / Safari             | ❌ 不支持 WebHID |
| Android / iOS 浏览器         | ❌ 不支持 WebHID |

必须在 **HTTPS**（或 `localhost`）下打开页面。连接操作必须由用户点击触发。

## 本地开发

要求 Node.js 22+。

```bash
npm install
npm run dev
```

打开终端提示的本地地址，使用桌面版 Chrome / Edge / Opera。点击「建立连接」，在浏览器弹窗中选择 `XiaomiPowerBank`。

### 连接真实设备

1. 使用支持数据传输的 USB-C 线，把移动电源的「指定 USB-C 口」连到电脑。具体接口见 `/models` 页面。
2. 在 4 秒内连续快速按 8 次移动电源按键，进入数据传输模式。
3. 点击页面上的「建立连接」，在浏览器配对弹窗中选择 `XiaomiPowerBank`。
4. 首次握手成功后，页面会读取电池信息、电芯状态和电芯编码。

> 不同型号的指定接口不同；部分型号会隐藏 SN 或只提供第一个测温点，这些行为已在代码中处理。

## 构建与部署

```bash
npm run typecheck
npm test
npm run build
```

构建产物在 `dist/`。

### Cloudflare Pages（推荐）

当前在线站点采用 Cloudflare Pages 直接上传。向 GitHub 提交代码不会自动更新该站点；维护者可构建后上传 dist，或登录 Wrangler 后执行 npm run deploy。新建 Git 集成项目时可使用以下配置：

- Framework preset：`Vite`
- Build command：`npm run build`
- Build output directory：`dist`
- Node version：`22`（仓库内的 `.nvmrc` 已声明）

仓库已包含：

- `public/_redirects`：尾斜杠规范化；SPA 路由由静态 HTML 外壳和 `404.html` 处理
- `public/_headers`：基础安全响应头与静态资源缓存
- `wrangler.toml`：`pages_build_output_dir = "dist"`

### SEO

- `src/seo/site.ts` 是页面标题、描述、关键词、canonical、Open Graph、Twitter Card 与 JSON-LD 的单一来源。
- `scripts/vite-plugin-seo.ts` 在构建时为 `/`、`/models`、`/exception-guide` 生成带独立元信息的静态 HTML 外壳，并输出 `404.html` 与 `sitemap.xml`；禁用 JavaScript 时还有可读的 `<noscript>` 内容。
- `public/robots.txt` 指向 sitemap，`public/og-image.png` 是 1200×630 的社交分享图。
- 使用自定义域名时，修改 `SITE_URL` 以及 `public/robots.txt` 中的 `Sitemap` 地址。

也可以使用 Wrangler 直接发布：

```bash
npx wrangler login
npm run deploy
```

`npm run deploy` 会执行构建并调用：

```bash
wrangler pages deploy dist --project-name mipluswpb1026s --branch main
```

## 项目结构

```text
.
├─ docs/
│  ├─ REVERSE_ENGINEERING.md      # 逆向记录、协议表、来源与已知限制
│  └─ images/                     # README 截图
├─ public/
│  ├─ _headers                    # Cloudflare Pages 响应头
│  ├─ _redirects                  # 尾斜杠规范化
│  ├─ favicon.svg
│  ├─ og-image.png                # 1200×630 社交分享图
│  └─ robots.txt
├─ scripts/
│  └─ vite-plugin-seo.ts          # 静态 HTML 外壳、sitemap、404 生成
├─ src/
│  ├─ assets/styles/              # 设计 token 与基础样式
│  ├─ components/                 # 连接卡片、设备面板、电芯表、协议日志等
│  ├─ composables/                # i18n、toast
│  ├─ data/
│  │  ├─ models.ts                # 支持型号表
│  │  ├─ batteryIdMaps.ts         # 电芯编码/厂商/小米项目映射
│  │  └─ i18n/                    # 中英文文案
│  ├─ lib/
│  │  ├─ hid/                     # WebHID / 模拟传输层、设备客户端
│  │  └─ protocol/                # CRC、帧、解码器、格式化
│  ├─ router/
│  ├─ seo/                        # 页面元数据、canonical 与 JSON-LD
│  ├─ stores/device.ts            # Pinia 设备状态与会话流程
│  ├─ tests/                      # Vitest 协议与模拟设备测试
│  ├─ types/
│  └─ views/                      # 设备页、支持型号、异常指引
├─ index.html
├─ vite.config.ts
├─ wrangler.toml
└─ package.json
```

## 协议摘要

完整说明见 [`docs/REVERSE_ENGINEERING.md`](docs/REVERSE_ENGINEERING.md)。

- 32 字节 HID 报告，`reportId = 0`
- 通用帧：`A5 | CMD | LEN | PAYLOAD | CRC8`，不足 32 字节补零
- CRC：CRC-8/ATM，多项式 `0x07`，初值 `0x00`
- 握手：特殊 `Hello` 帧，包含北京时间戳和 `xiaomi-pb` magic
- 主要响应：`0x10` Hello、`0x11` 电池信息、`0x12` 电芯状态、`0x13` 异常记录、`0x14` 电芯编码、`0x18` 温度阈值/型号
- 心跳：每 15 秒重发一次 Hello 帧

## 模拟测试

首页已移除「查看演示数据」按钮。自动测试继续使用 `MockTransport` 模拟：

- 2 节电芯
- 86% 电量、97% 健康度、37 次循环
- 两个温度传感器
- 可切换的 Qi2.2 状态
- 三条历史异常记录
- 模拟的原始 HID 帧与协议日志

模拟传输层不会访问真实 HID 设备，供开发验证使用。

## 测试

```bash
npm test          # Vitest：CRC、帧解析、解码器、模拟设备会话
npm run typecheck # vue-tsc
```

测试覆盖：

- CRC-8 计算
- Hello / 命令帧构造与零填充
- 多帧输入报告提取与不完整帧保留
- 电池信息、电芯状态、电芯编码、温度阈值、历史记录、Qi2.2 状态/开关解码
- 使用模拟传输层完成握手 → 电池信息 → 电芯 → 编码 → 温度 → Qi2.2 → 历史 → 断开的完整流程

## 隐私与安全

- 无自建后端；地区检测请求发送至 country.is，不携带设备数据。页面无第三方访问量统计
- 不写入固件、不修改电池参数；默认只发送读取类命令和断开命令
- 仅对 `WPB1025S`、`WPB1026S` 提供带二次确认的 Qi2.2 开关，其他型号不会显示写入控件
- 页面不提供任意原始命令输入，避免误操作
- WebHID 访问需要显式用户手势与浏览器授权

## 参考与致谢

- 原始页面：[powerbank.mieco.net](https://powerbank.mieco.net/)
- 协议参考（Python HID 工具，MIT）：[yomiel-s/xiaomi-powerbank-tools](https://github.com/yomiel-s/xiaomi-powerbank-tools)
- WebHID 规范：[WICG/webhid](https://github.com/WICG/webhid)
- UI 参考（未复用代码）：[xingrz/ChargeMon](https://github.com/xingrz/ChargeMon)、[Smart-financial-class/PowerMonitor](https://github.com/Smart-financial-class/PowerMonitor)

本版本基于 LOSRET/xiaomi-powerbank-console 修改；上游为独立重写的前端。电芯编码表、型号表和界面文案用于设备互操作与信息展示。

## License

MIT。详见 [LICENSE](LICENSE)。

Xiaomi 及相关名称为小米公司的商标。本项目与小米公司无隶属关系，也不代表其官方立场。

## 完整源码下载

[下载完整源码 ZIP](downloads/xiaomi-powerbank-console-WPB1026S-source.zip)；也可以使用 GitHub 的 Code → Download ZIP。源码包含依赖锁文件，不包含 node_modules、构建缓存或登录凭据。
